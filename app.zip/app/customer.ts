export class Customer {

 email: string ;
 name: string;
 password: string;
 confirmpassword: string;
 number: number;
 address: string;
 city: string;
 zipcode: string;
 country: string ;

}
